/*
//Hardware pin definitions
const byte REFERENCE_3V3 = A3;
const byte LIGHT = A1;
const byte BATT = A2;
const byte STAT_BLUE = A4;
const byte STAT_GREEN = A5;
*/

#pragma once

#if defined(ARDUINO) && ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif


class WeatherConfig {

public:
  WeatherConfig();

  //Public Functions

void calibration();
float get_humidity();
float get_temperature();
float get_temperature_f();
float get_pressure();
float get_light_level(float value1, float value2);
float get_battery_level(float, float);
  //Public Variables

private:
  //Private Functions

  //Private Variables

};
